---
title: 服务类目
header: introduction
nav: book
sidebar: category
---



请根据界面提示上传所需资质文件

![图片](../../img/introduction/register/4.1.png)
小程序创建完成后，无需等待服务类目审核完成，登录 [智能小程序开发者后台](https://smartprogram.baidu.com/mappconsole/main/login) 。 打开“智能小程序首页”-“设置”-“开发设置”， 查看智能小程序的 AppID，以便尽快进入到开发环节。

服务类目状态将影响您的小程序发布，因此请在开发完成前务必确保服务类目审核通过。