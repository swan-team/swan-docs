---
title: 百家号流量介绍
header: introduction
nav: book
sidebar: baijiahaointroduction
---
百家号文章挂载智能小程序是一种为小程序获取流量的新方式，开发者可在发布百家号文章时，在文内插入相关的智能小程序来获得展现机会，获得更多分发。通过将百家号流量成功接入智能小程序，从而打造一个更加开放、互联互通的小程序生态。

## 入口介绍

挂载智能小程序的文章通过信息流进行展现：
1. 文章在信息流中展现；
2. 点击进入文章；
3. 点击文中插入的小程序卡片进入小程序。

![图片](../../img/introduction/scancode/baijiahao.gif)