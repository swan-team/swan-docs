---
title: 登录与注册
header: introduction
nav: book
sidebar: enter_application
---

   
   打开[智能小程序官网首页](https://smartprogram.baidu.com/mappconsole/main/login)，点击右上方“登录”按钮。

 ![图片](../../img/introduction/enter/p1.png)

 

目前支持百度账号及百度商业账号登录

* 百度账号：您可以使用百家号、熊掌ID非个人类型的账号快速入驻
* 百度商业账号：您可以使用百度推广、百青藤、百度电商账号直接登录

 ![图片](../../img/introduction/enter/p2.png)





