---
title: 完善 基本信息
header: introduction
nav: book
sidebar: register_consummate
---

主体认证审核通过后，您可先操作“创建智能小程序”

![图片](../../img/introduction/register/3.png)



填写智能小程序名称、简介、上传头像并选择服务范围。如果选择为特殊行业，还需根据界面提示提交相应资质材料。
关于小程序名称：请参考<a href="https://smartprogram.baidu.com/docs/operations/specification/">平台运营规范</a>。


![图片](../../img/introduction/register/4.png)

若填写的智能小程序名称涉及品牌或名称侵权需提交相关资料进行审核。

![图片](../../img/introduction/register/5.png)
![图片](../../img/introduction/register/6.png)




填写智能小程序名称、简介、标签、上传头像并选择服务范围。如果选择为特殊行业，还需根据界面提示提交相应资质，审核预计需要2个工作日完成，在此期间不会影响您进行小程序开发。
![图片](../../img/introduction/register/p16.png)



