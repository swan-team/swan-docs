---
title: 主体类型选择
header: introduction
nav: book
sidebar: register_choosebodystyle
---

点击“下一步”进入主体信息提交环节。

![图片](../../img/introduction/register/1.1.png)



目前支持的主体类型：媒体、企业、政府、其他组织。
> 暂不支持个人主体类型开发者入驻。
> 主体类型一旦选择后将无法更改。

![图片](../../img/introduction/register/1.2.png)