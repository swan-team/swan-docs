---
title: 素材审核
header: introduction
nav: book
sidebar: accessfeed_examine
---
 

 

### 审核概况

当您进行批量素材上传后，我们将尽快对您上传的素材进行审核，并给予您素材相关建议，您可以根据建议用于后续补充素材物料上传。



![图片](../../img/introduction/auditing/图13.png) 

**字段信息请参考开发文档** [submitresource](/develop/serverapi/submitresource/)

 

### 审核结果



![图片](../../img/introduction/auditing/图14.png) 

 

## **信息流收录分发**

当您的素材在后台界面中状态显示为“投放中”时，说明您的素材已被信息流收录并会根据实际情况进行相应分发，具体展示样式将根据您提交的素材物料，由百度信息流决定展现具体样式，您可以在开发者后台，数据分析模块查看到信息流入口获取到的流量效果。

 