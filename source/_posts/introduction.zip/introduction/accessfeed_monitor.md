---
title: 流量效果监控
header: introduction
nav: book
sidebar: accessfeed_monitor
---




![图片](../../img/introduction/auditing/图16.png) 

 

您可从开发者后台数据分析模块了解到信息流流量为您带来的流量收益。