---
title: 开发工具
header: introduction
nav: book
sidebar: tool
---

 

下载开发者工具（[Windows 64版下载地址](https://smartprogram.baidu.com/mappconsole/api/devDownload?system=windows&type=online)  |   [Mac版下载地址](https://smartprogram.baidu.com/mappconsole/api/devDownload?system=mac&type=online)）进行代码开发和上传。


<div class="m-doc-custom-examples">
	<div class="m-doc-custom-examples-correct">
		<img src="../../img/introduction/register/9.png">
		<!-- <p class="m-doc-custom-examples-title">正确</p><p class="m-doc-custom-examples-text">内容左右边距应至少34px(17pt)。</p> -->
	</div>
	<div class="m-doc-custom-examples-error ">
		<img src="../../img/introduction/register/10.png">
		<!-- <p class="m-doc-custom-examples-title">错误</p><p class="m-doc-custom-examples-text">边距过宽，页面元素过于集中。</p> -->
	</div>
</div>

![图片](../../img/introduction/register/11.png)<br/>
