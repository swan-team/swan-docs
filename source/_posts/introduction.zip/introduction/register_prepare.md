---
title: 开发前准备
header: introduction
nav: book
sidebar: register_prepare
---


## 成员管理


登录智能小程序平台，进入平台首页- 成员管理，添加智能小程序项目成员并配置成员权限，一个智能小程序只能添加一名管理员。
![图片](../../img/introduction/register/7.png)

## 获取 AppID

进入“平台首页-设置”，获取 AppID（智能小程序 ID）、App Key、App Secret（智能小程序密钥）。 
![图片](../../img/introduction/register/8.png)

## 配置服务器 
在开发设置页面查看 AppID 和 AppSecret，配置服务器域名。

![图片](../../img/introduction/register/33.png)

