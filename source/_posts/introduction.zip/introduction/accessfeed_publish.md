---
title: 接小程序发布上线
header: introduction
nav: book
sidebar: accessfeed_publish
---




![图片](../../img/introduction/auditing/图2.png) 

当您的小程序尚未发布上线时，“素材资料提交”按钮将置灰，您的小程序发布上线后，该按钮即被点亮，如下图



![图片](../../img/introduction/auditing/图3.png) 



![图片](../../img/introduction/auditing/图4.png) 

在您的小程序尚未发布前，您也可以提前通过阅读“[信息流资源](https://smartprogram.baidu.com/docs/develop/serverapi/open_feed/#信息流物料提交简介/)”以及“[信息流流量说明](https://smartprogram.baidu.com/docs/introduction/feed/)”全面了解信息流流量的玩法及素材提交管理流程。