---
title: 素材优化建议
header: introduction
nav: book
sidebar: accessfeed_suggest
---



![图片](../../img/introduction/auditing/图15.png) 

该模块会显示当前的top5待优化问题，您可参考“优化建议”对相应素材内容进行优化，同时您也可以下载问题样例具体查看问题详情，素材完成优化后您可重新上传素材内容，系统会尽快对已解决问题进行校验。